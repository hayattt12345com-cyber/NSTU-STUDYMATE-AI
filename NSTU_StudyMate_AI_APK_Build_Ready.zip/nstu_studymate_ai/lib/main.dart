import 'dart:convert';
import 'dart:math';
import 'package:file_picker/file_picker.dart';
import 'package:flutter/material.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import 'package:syncfusion_flutter_pdf/pdf.dart';

const supabaseUrl = String.fromEnvironment('SUPABASE_URL');
const supabaseAnonKey = String.fromEnvironment('SUPABASE_ANON_KEY');
const storageBucket = 'study-pdfs';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  if (supabaseUrl.isEmpty || supabaseAnonKey.isEmpty) {
    runApp(const SetupRequiredApp());
    return;
  }
  await Supabase.initialize(url: supabaseUrl, anonKey: supabaseAnonKey);
  runApp(const StudyMateApp());
}

class SetupRequiredApp extends StatelessWidget {
  const SetupRequiredApp({super.key});

  @override
  Widget build(BuildContext context) => MaterialApp(
    title: 'NSTU StudyMate AI',
    debugShowCheckedModeBanner: false,
    theme: ThemeData(colorScheme: ColorScheme.fromSeed(seedColor: const Color(0xFF2457C5)), useMaterial3: true),
    home: Scaffold(
      body: SafeArea(
        child: Center(
          child: SingleChildScrollView(
            padding: const EdgeInsets.all(24),
            child: ConstrainedBox(
              constraints: const BoxConstraints(maxWidth: 480),
              child: Column(mainAxisSize: MainAxisSize.min, children: [
                const Icon(Icons.school_rounded, size: 72, color: Color(0xFF2457C5)),
                const SizedBox(height: 16),
                const Text('NSTU StudyMate AI', textAlign: TextAlign.center, style: TextStyle(fontSize: 26, fontWeight: FontWeight.bold)),
                const SizedBox(height: 12),
                const Text('The Android app build is ready, but its backend has not been connected yet.', textAlign: TextAlign.center),
                const SizedBox(height: 20),
                const Align(alignment: Alignment.centerLeft, child: Text('Complete these setup steps:', style: TextStyle(fontWeight: FontWeight.bold))),
                const SizedBox(height: 8),
                const Text('1. Create a Supabase project.\n2. Run supabase/schema.sql and configure the private study-pdfs Storage bucket.\n3. Deploy supabase/functions/study-ai and set GEMINI_API_KEY as a Supabase secret.\n4. Rebuild with SUPABASE_URL and SUPABASE_ANON_KEY configured.'),
              ]),
            ),
          ),
        ),
      ),
    ),
  );
}

final supabase = Supabase.instance.client;

class StudyMateApp extends StatelessWidget {
  const StudyMateApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'NSTU StudyMate AI',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        colorScheme: ColorScheme.fromSeed(seedColor: const Color(0xFF2457C5)),
        useMaterial3: true,
        scaffoldBackgroundColor: const Color(0xFFF7F8FC),
      ),
      home: const AuthGate(),
    );
  }
}

class AuthGate extends StatelessWidget {
  const AuthGate({super.key});

  @override
  Widget build(BuildContext context) {
    return StreamBuilder<AuthState>(
      stream: supabase.auth.onAuthStateChange,
      builder: (context, snapshot) {
        if (supabase.auth.currentUser != null) return const HomePage();
        return const SignInPage();
      },
    );
  }
}

class SignInPage extends StatefulWidget {
  const SignInPage({super.key});
  @override
  State<SignInPage> createState() => _SignInPageState();
}

class _SignInPageState extends State<SignInPage> {
  final email = TextEditingController();
  final password = TextEditingController();
  bool loading = false;
  bool createAccount = false;

  Future<void> submit() async {
    setState(() => loading = true);
    try {
      if (createAccount) {
        await supabase.auth.signUp(email: email.text.trim(), password: password.text);
      } else {
        await supabase.auth.signInWithPassword(email: email.text.trim(), password: password.text);
      }
    } on AuthException catch (e) {
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(e.message)));
    } catch (e) {
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Error: $e')));
    } finally {
      if (mounted) setState(() => loading = false);
    }
  }

  @override
  Widget build(BuildContext context) => Scaffold(
    body: Center(
      child: SingleChildScrollView(
        padding: const EdgeInsets.all(24),
        child: ConstrainedBox(
          constraints: const BoxConstraints(maxWidth: 420),
          child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
            const Icon(Icons.school_rounded, size: 64, color: Color(0xFF2457C5)),
            const SizedBox(height: 12),
            const Text('NSTU StudyMate AI', textAlign: TextAlign.center,
              style: TextStyle(fontSize: 26, fontWeight: FontWeight.bold)),
            const SizedBox(height: 8),
            const Text('Your notes. Your questions. Your success.',
              textAlign: TextAlign.center, style: TextStyle(color: Colors.black54)),
            const SizedBox(height: 28),
            TextField(controller: email, keyboardType: TextInputType.emailAddress,
              decoration: const InputDecoration(labelText: 'Email', border: OutlineInputBorder())),
            const SizedBox(height: 12),
            TextField(controller: password, obscureText: true,
              decoration: const InputDecoration(labelText: 'Password (min. 6 characters)', border: OutlineInputBorder())),
            const SizedBox(height: 16),
            FilledButton(onPressed: loading ? null : submit,
              child: Text(loading ? 'Please wait…' : (createAccount ? 'Create account' : 'Sign in'))),
            TextButton(onPressed: () => setState(() => createAccount = !createAccount),
              child: Text(createAccount ? 'Already have an account? Sign in' : 'New here? Create an account')),
          ]),
        ),
      ),
    ),
  );
}

class HomePage extends StatefulWidget {
  const HomePage({super.key});
  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  int tab = 0;
  @override
  Widget build(BuildContext context) {
    final pages = [const LibraryPage(), const StudyAiPage(), const SavedPage()];
    return Scaffold(
      appBar: AppBar(
        title: const Text('NSTU StudyMate AI', style: TextStyle(fontWeight: FontWeight.bold)),
        actions: [IconButton(tooltip: 'Sign out', onPressed: () => supabase.auth.signOut(),
          icon: const Icon(Icons.logout_rounded))],
      ),
      body: pages[tab],
      bottomNavigationBar: NavigationBar(
        selectedIndex: tab,
        onDestinationSelected: (v) => setState(() => tab = v),
        destinations: const [
          NavigationDestination(icon: Icon(Icons.library_books_outlined), selectedIcon: Icon(Icons.library_books), label: 'My PDFs'),
          NavigationDestination(icon: Icon(Icons.auto_awesome_outlined), selectedIcon: Icon(Icons.auto_awesome), label: 'Study AI'),
          NavigationDestination(icon: Icon(Icons.bookmark_border), selectedIcon: Icon(Icons.bookmark), label: 'Saved'),
        ],
      ),
    );
  }
}

class LibraryPage extends StatefulWidget {
  const LibraryPage({super.key});
  @override
  State<LibraryPage> createState() => _LibraryPageState();
}

class _LibraryPageState extends State<LibraryPage> {
  bool uploading = false;
  Future<List<Map<String, dynamic>>> loadDocs() async {
    final rows = await supabase.from('documents').select().order('created_at', ascending: false);
    return List<Map<String, dynamic>>.from(rows);
  }

  String makeSafeName(String name) => name.replaceAll(RegExp(r'[^a-zA-Z0-9._-]'), '_');

  Future<void> uploadPdf() async {
    final picked = await FilePicker.platform.pickFiles(type: FileType.custom, allowedExtensions: ['pdf', 'txt'], withData: true);
    if (picked == null || picked.files.single.bytes == null) return;
    final file = picked.files.single;
    final bytes = file.bytes!;
    setState(() => uploading = true);
    try {
      final isPdf = file.name.toLowerCase().endsWith('.pdf');
      String fullText;
      int? pageCount;
      if (isPdf) {
        final doc = PdfDocument(inputBytes: bytes);
        final pages = <String>[];
        for (int i = 0; i < doc.pages.count; i++) {
          pages.add(PdfTextExtractor(doc).extractText(startPageIndex: i, endPageIndex: i));
        }
        pageCount = pages.length;
        fullText = pages.join('\n\n').trim();
        doc.dispose();
        if (fullText.isEmpty) {
          throw Exception('No selectable text found. This may be a scanned PDF; OCR support is needed.');
        }
      } else {
        fullText = utf8.decode(bytes, allowMalformed: true).trim();
        if (fullText.isEmpty) throw Exception('The text file is empty.');
      }
      final userId = supabase.auth.currentUser!.id;
      final path = '$userId/${DateTime.now().millisecondsSinceEpoch}_${makeSafeName(file.name)}';
      await supabase.storage.from(storageBucket).uploadBinary(path, bytes,
        fileOptions: FileOptions(contentType: isPdf ? 'application/pdf' : 'text/plain', upsert: false));
      final inserted = await supabase.from('documents').insert({
        'user_id': userId,
        'title': file.name,
        'storage_path': path,
        'page_count': pageCount,
      }).select().single();
      final docId = inserted['id'] as String;
      final chunks = _chunkText(fullText, 2200, 250);
      for (int start = 0; start < chunks.length; start += 20) {
        final batch = <Map<String, dynamic>>[];
        for (int j = start; j < min(start + 20, chunks.length); j++) {
          batch.add({
            'document_id': docId,
            'user_id': userId,
            'chunk_index': j,
            'content': chunks[j],
          });
        }
        await supabase.from('document_chunks').insert(batch);
      }
      // No prompt required: create the default study pack automatically.
      final aiResponse = await supabase.functions.invoke('study-ai', body: {
        'topic': 'Analyze the newly uploaded material "${file.name}" and create the complete study pack.',
        'mode': 'auto_pack',
        'language': 'both',
        'document_id': docId,
      });
      final aiData = Map<String, dynamic>.from(aiResponse.data as Map);
      final studyPack = aiData['answer']?.toString() ?? 'Study pack could not be generated.';
      await supabase.from('saved_notes').insert({
        'user_id': userId,
        'title': 'Auto Study Pack — ${file.name}',
        'content': studyPack,
        'mode': 'auto_pack',
      });
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Uploaded and analyzed ${file.name}. Study pack saved!')));
        setState(() {});
      }
    } catch (e) {
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Upload failed: $e')));
    } finally {
      if (mounted) setState(() => uploading = false);
    }
  }

  List<String> _chunkText(String text, int size, int overlap) {
    final chunks = <String>[];
    int start = 0;
    while (start < text.length) {
      final end = min(start + size, text.length);
      chunks.add(text.substring(start, end));
      if (end == text.length) break;
      start = end - overlap;
    }
    return chunks;
  }


  Future<void> addPastedText() async {
    final titleController = TextEditingController();
    final textController = TextEditingController();
    final accepted = await showDialog<bool>(
      context: context,
      builder: (dialogContext) => AlertDialog(
        title: const Text('Add text or lecture notes'),
        content: SizedBox(
          width: 500,
          child: Column(mainAxisSize: MainAxisSize.min, children: [
            TextField(controller: titleController, decoration: const InputDecoration(labelText: 'Title')),
            const SizedBox(height: 10),
            TextField(controller: textController, minLines: 5, maxLines: 10,
              decoration: const InputDecoration(labelText: 'Paste your text here', border: OutlineInputBorder())),
          ]),
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(dialogContext, false), child: const Text('Cancel')),
          FilledButton(onPressed: () => Navigator.pop(dialogContext, true), child: const Text('Analyze automatically')),
        ],
      ),
    );
    if (accepted != true || textController.text.trim().isEmpty) return;
    setState(() => uploading = true);
    try {
      final userId = supabase.auth.currentUser!.id;
      final title = titleController.text.trim().isEmpty ? 'Pasted notes ${DateTime.now().toIso8601String().substring(0, 10)}' : titleController.text.trim();
      final fullText = textController.text.trim();
      final path = '$userId/${DateTime.now().millisecondsSinceEpoch}_pasted_text.txt';
      await supabase.storage.from(storageBucket).uploadBinary(
        path, utf8.encode(fullText),
        fileOptions: const FileOptions(contentType: 'text/plain', upsert: false),
      );
      final inserted = await supabase.from('documents').insert({
        'user_id': userId, 'title': title, 'storage_path': path, 'page_count': null,
      }).select().single();
      final docId = inserted['id'] as String;
      final chunks = _chunkText(fullText, 2200, 250);
      for (int j = 0; j < chunks.length; j += 20) {
        final batch = <Map<String, dynamic>>[];
        for (int k = j; k < min(j + 20, chunks.length); k++) {
          batch.add({'document_id': docId, 'user_id': userId, 'chunk_index': k, 'content': chunks[k]});
        }
        await supabase.from('document_chunks').insert(batch);
      }
      final response = await supabase.functions.invoke('study-ai', body: {
        'topic': 'Analyze the newly submitted material "$title" and create the complete study pack.',
        'mode': 'auto_pack', 'language': 'both', 'document_id': docId,
      });
      final data = Map<String, dynamic>.from(response.data as Map);
      await supabase.from('saved_notes').insert({
        'user_id': userId, 'title': 'Auto Study Pack — $title',
        'content': data['answer']?.toString() ?? 'Study pack could not be generated.',
        'mode': 'auto_pack',
      });
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Text analyzed. Your study pack is saved!')));
        setState(() {});
      }
    } catch (e) {
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Could not analyze text: $e')));
    } finally {
      if (mounted) setState(() => uploading = false);
    }
  }

  Future<void> deleteDoc(Map<String, dynamic> row) async {
    try {
      await supabase.from('document_chunks').delete().eq('document_id', row['id']);
      await supabase.storage.from(storageBucket).remove([row['storage_path'] as String]);
      await supabase.from('documents').delete().eq('id', row['id']);
      if (mounted) setState(() {});
    } catch (e) {
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Delete failed: $e')));
    }
  }

  @override
  Widget build(BuildContext context) => Padding(
    padding: const EdgeInsets.all(16),
    child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      const Text('My PDF Library', style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold)),
      const SizedBox(height: 4),
      const Text('Upload class notes, lecture PDFs and question papers.'),
      const SizedBox(height: 16),
      SizedBox(width: double.infinity, child: FilledButton.icon(
        onPressed: uploading ? null : uploadPdf,
        icon: uploading ? const SizedBox(width: 18, height: 18, child: CircularProgressIndicator(strokeWidth: 2)) : const Icon(Icons.upload_file),
        label: Text(uploading ? 'Processing material…' : 'Upload PDF or TXT'))),
      const SizedBox(height: 8),
      SizedBox(width: double.infinity, child: OutlinedButton.icon(
        onPressed: uploading ? null : addPastedText,
        icon: const Icon(Icons.edit_note),
        label: const Text('Paste text / lecture notes'))),
      const SizedBox(height: 12),
      Expanded(child: FutureBuilder<List<Map<String, dynamic>>>(
        future: loadDocs(),
        builder: (context, snap) {
          if (snap.connectionState == ConnectionState.waiting) return const Center(child: CircularProgressIndicator());
          if (snap.hasError) return Center(child: Text('Could not load PDFs: ${snap.error}'));
          final docs = snap.data ?? [];
          if (docs.isEmpty) return const Center(child: Text('No PDFs yet. Upload your first study file.'));
          return ListView.separated(itemCount: docs.length, separatorBuilder: (_, __) => const SizedBox(height: 8),
            itemBuilder: (context, i) {
              final d = docs[i];
              return Card(child: ListTile(
                leading: const CircleAvatar(child: Icon(Icons.picture_as_pdf)),
                title: Text(d['title'] as String? ?? 'Untitled PDF', maxLines: 2, overflow: TextOverflow.ellipsis),
                subtitle: Text('${d['page_count'] ?? '?'} pages'),
                trailing: IconButton(icon: const Icon(Icons.delete_outline), onPressed: () => deleteDoc(d)),
              ));
            });
        },
      )),
    ]),
  );
}

class StudyAiPage extends StatefulWidget {
  const StudyAiPage({super.key});
  @override
  State<StudyAiPage> createState() => _StudyAiPageState();
}

class _StudyAiPageState extends State<StudyAiPage> {
  final topic = TextEditingController();
  String mode = 'questions';
  String language = 'both';
  String result = '';
  bool loading = false;

  Future<void> generate() async {
    if (topic.text.trim().isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Upload a PDF/TXT or paste notes in My PDFs for automatic analysis.')));
      return;
    }
    setState(() { loading = true; result = ''; });
    try {
      final response = await supabase.functions.invoke('study-ai', body: {
        'topic': topic.text.trim(),
        'mode': mode,
        'language': language,
      });
      final data = Map<String, dynamic>.from(response.data as Map);
      result = data['answer']?.toString() ?? 'No answer returned.';
      if (mounted) setState(() {});
    } catch (e) {
      result = 'Could not generate content: $e\n\nCheck that the Edge Function is deployed and GEMINI_API_KEY is configured.';
      if (mounted) setState(() {});
    } finally {
      if (mounted) setState(() => loading = false);
    }
  }

  Future<void> saveResult() async {
    if (result.trim().isEmpty) return;
    await supabase.from('saved_notes').insert({
      'user_id': supabase.auth.currentUser!.id,
      'title': topic.text.trim(),
      'content': result,
      'mode': mode,
    });
    if (mounted) ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Saved to your notes')));
  }

  @override
  Widget build(BuildContext context) => ListView(padding: const EdgeInsets.all(16), children: [
    const Text('Study AI', style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold)),
    const SizedBox(height: 4),
    const Text('Generate study material from your uploaded PDFs.'),
    const SizedBox(height: 16),
    DropdownButtonFormField<String>(
      value: mode,
      decoration: const InputDecoration(labelText: 'What do you need?', border: OutlineInputBorder()),
      items: const [
        DropdownMenuItem(value: 'questions', child: Text('Questions + answers')),
        DropdownMenuItem(value: 'summary', child: Text('Summary / notes')),
        DropdownMenuItem(value: 'mcq', child: Text('MCQ quiz')),
        DropdownMenuItem(value: 'mock_test', child: Text('Mock test')),
      ],
      onChanged: (v) => setState(() => mode = v ?? 'questions'),
    ),
    const SizedBox(height: 12),
    DropdownButtonFormField<String>(
      value: language,
      decoration: const InputDecoration(labelText: 'Language', border: OutlineInputBorder()),
      items: const [
        DropdownMenuItem(value: 'both', child: Text('English + Bangla')),
        DropdownMenuItem(value: 'english', child: Text('English')),
        DropdownMenuItem(value: 'bangla', child: Text('Bangla')),
      ],
      onChanged: (v) => setState(() => language = v ?? 'both'),
    ),
    const SizedBox(height: 12),
    TextField(controller: topic, minLines: 2, maxLines: 4,
      decoration: const InputDecoration(
        labelText: 'Topic or question',
        hintText: 'Optional: type a topic. Leave blank only when using auto-analysis after upload.',
        border: OutlineInputBorder(),
      )),
    const SizedBox(height: 12),
    FilledButton.icon(onPressed: loading ? null : generate,
      icon: loading ? const SizedBox(width: 18, height: 18, child: CircularProgressIndicator(strokeWidth: 2)) : const Icon(Icons.auto_awesome),
      label: Text(loading ? 'Generating…' : 'Generate from my PDFs')),
    if (result.isNotEmpty) ...[
      const SizedBox(height: 20),
      Card(child: Padding(padding: const EdgeInsets.all(16), child: SelectableText(result))),
      OutlinedButton.icon(onPressed: saveResult, icon: const Icon(Icons.bookmark_add_outlined), label: const Text('Save this result')),
    ],
  ]);
}

class SavedPage extends StatefulWidget {
  const SavedPage({super.key});
  @override
  State<SavedPage> createState() => _SavedPageState();
}

class _SavedPageState extends State<SavedPage> {
  @override
  Widget build(BuildContext context) => FutureBuilder<List<Map<String, dynamic>>>(
    future: supabase.from('saved_notes').select().order('created_at', ascending: false).then((v) => List<Map<String, dynamic>>.from(v)),
    builder: (context, snap) {
      if (snap.connectionState == ConnectionState.waiting) return const Center(child: CircularProgressIndicator());
      if (snap.hasError) return Center(child: Text('Could not load saved notes: ${snap.error}'));
      final rows = snap.data ?? [];
      if (rows.isEmpty) return const Center(child: Text('Your saved study notes will appear here.'));
      return ListView.builder(padding: const EdgeInsets.all(12), itemCount: rows.length, itemBuilder: (context, i) {
        final r = rows[i];
        return Card(child: ExpansionTile(
          title: Text(r['title'] as String? ?? 'Saved note'),
          subtitle: Text(r['mode'] as String? ?? ''),
          childrenPadding: const EdgeInsets.all(16),
          children: [SelectableText(r['content'] as String? ?? '')],
        ));
      });
    },
  );
}
