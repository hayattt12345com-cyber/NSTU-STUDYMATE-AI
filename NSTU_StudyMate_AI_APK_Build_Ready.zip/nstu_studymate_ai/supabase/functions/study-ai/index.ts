import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
};

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") return new Response("ok", { headers: corsHeaders });
  try {
    const authHeader = req.headers.get("Authorization");
    if (!authHeader) return json({ error: "Missing authorization" }, 401);

    const supabaseUrl = Deno.env.get("SUPABASE_URL")!;
    const anonKey = Deno.env.get("SUPABASE_ANON_KEY")!;
    const supabase = createClient(supabaseUrl, anonKey, {
      global: { headers: { Authorization: authHeader } },
    });
    const { data: userData, error: userError } = await supabase.auth.getUser();
    if (userError || !userData.user) return json({ error: "Unauthorized" }, 401);

    const body = await req.json();
    const topic = String(body.topic ?? "").trim();
    const mode = String(body.mode ?? "questions");
    const language = String(body.language ?? "both");
    const documentId = body.document_id ? String(body.document_id) : null;

    let query = supabase.from("document_chunks")
      .select("content, chunk_index, document_id")
      .order("document_id").order("chunk_index").limit(80);
    if (documentId) query = query.eq("document_id", documentId);
    const { data: chunks, error: chunksError } = await query;
    if (chunksError) throw chunksError;
    if (!chunks || chunks.length === 0) {
      return json({ answer: "No text chunks found. Upload a text-based PDF/TXT or paste notes first." });
    }

    const context = chunks.map((c, i) =>
      `[Source ${i + 1}; document ${c.document_id}; chunk ${c.chunk_index}]\n${c.content}`
    ).join("\n\n");

    const modeInstructions: Record<string, string> = {
      auto_pack: `Create a complete, organized study pack automatically, without asking the student for another prompt. Include:
1. Detected subject/topic and a 3-5 sentence overview.
2. Structured summary with headings and key bullet points.
3. Important terms and definitions.
4. Short questions with concise model answers.
5. Broad/essay questions with structured answer outlines.
6. 10 MCQs with four options, answer key, and explanations.
7. Viva questions.
8. Key takeaways and likely exam-focus areas, clearly marked as suggestions rather than guaranteed exam predictions.
9. Research directions: useful subtopics and keywords to investigate further, but do not claim external research was performed.
Use only the supplied source context for factual claims. Identify gaps and ambiguities instead of inventing details.`,
      questions: "Create useful exam questions with clear model answers. Include short and broad questions where relevant.",
      summary: "Create a structured, concise study summary with headings and bullet points.",
      mcq: "Create 10 multiple-choice questions, four options each, mark the correct answer and explain why.",
      mock_test: "Create a mock test with 10 questions. Put the answer key and short explanations at the end.",
    };
    const langInstructions: Record<string, string> = {
      both: "For each major section, write English first and then a clear Bangla translation/explanation.",
      english: "Write in clear academic English.",
      bangla: "Write in clear, natural Bangla.",
    };
    const prompt = `You are NSTU StudyMate AI for university students, initially for Information Science and Library Management.
Use ONLY the source context below for factual claims. If the context does not contain enough information, say so clearly. Never fabricate citations or page numbers.
Task: ${modeInstructions[mode] ?? modeInstructions.questions}
Language: ${langInstructions[language] ?? langInstructions.both}
Student topic/request: ${topic || "Automatically analyze this material and produce the appropriate study output."}

SOURCE CONTEXT:
${context.slice(0, 90000)}`;

    const apiKey = Deno.env.get("GEMINI_API_KEY");
    if (!apiKey) return json({ error: "GEMINI_API_KEY secret is not configured." }, 500);
    const model = Deno.env.get("GEMINI_MODEL") ?? "gemini-2.5-flash";
    const aiResponse = await fetch(
      `https://generativelanguage.googleapis.com/v1beta/models/${model}:generateContent?key=${apiKey}`,
      {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          contents: [{ role: "user", parts: [{ text: prompt }] }],
          generationConfig: { temperature: 0.3, maxOutputTokens: 7000 },
        }),
      },
    );
    const aiJson = await aiResponse.json();
    if (!aiResponse.ok) return json({ error: aiJson?.error?.message ?? "AI provider request failed." }, 502);
    const answer = aiJson?.candidates?.[0]?.content?.parts?.map((p: {text?: string}) => p.text ?? "").join("\n") ?? "No answer generated.";
    return json({ answer });
  } catch (error) {
    return json({ error: String(error) }, 500);
  }
});

function json(data: unknown, status = 200) {
  return new Response(JSON.stringify(data), {
    status,
    headers: { ...corsHeaders, "Content-Type": "application/json" },
  });
}
