-- Run after creating a PRIVATE Storage bucket named `study-pdfs`.
-- Supabase Dashboard > Storage > study-pdfs > Policies, or run equivalent SQL below.
create policy "Users can upload their own PDFs"
on storage.objects for insert to authenticated
with check (
  bucket_id = 'study-pdfs'
  and (storage.foldername(name))[1] = auth.uid()::text
);

create policy "Users can read their own PDFs"
on storage.objects for select to authenticated
using (
  bucket_id = 'study-pdfs'
  and (storage.foldername(name))[1] = auth.uid()::text
);

create policy "Users can delete their own PDFs"
on storage.objects for delete to authenticated
using (
  bucket_id = 'study-pdfs'
  and (storage.foldername(name))[1] = auth.uid()::text
);
