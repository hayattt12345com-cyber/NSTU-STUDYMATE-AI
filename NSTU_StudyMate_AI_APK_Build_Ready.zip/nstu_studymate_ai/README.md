# NSTU StudyMate AI — Android APK build starter

Flutter + Supabase starter for NSTU students. The app accepts selectable-text PDF files, TXT files, and pasted notes, then automatically creates a bilingual English/Bangla study pack with a summary, key terms, short and broad Q&A, 10 MCQs, viva questions, key takeaways, and suggested research directions.

**Important:** This repository is source code plus an automated cloud build workflow. An APK has not been compiled in this environment because Flutter and the Android SDK are not installed here. The GitHub Actions workflow below can build the APK once you upload the project to a GitHub repository.

## 1. Set up the AI backend (required for real use)

1. Create a project at Supabase.
2. In Supabase SQL Editor, run `supabase/schema.sql`.
3. Create a **private** Storage bucket named `study-pdfs`.
4. Run `supabase/storage-policies.sql`.
5. Install the Supabase CLI on your own computer, log in, and link the project:
   ```bash
   supabase login
   supabase link --project-ref YOUR_PROJECT_REF
   supabase functions deploy study-ai
   supabase secrets set GEMINI_API_KEY=YOUR_GEMINI_API_KEY
   ```
6. In your Supabase project settings, copy the Project URL and the anon/publishable client key. Do not use the service-role key in the app.

The Gemini key stays in Supabase Function secrets, never in the Android app. The `SUPABASE_URL` and `SUPABASE_ANON_KEY` values are client configuration, not the service-role secret.

## 2. Build the APK using GitHub Actions (no local Android SDK needed)

1. Create a GitHub repository, for example `nstu-studymate-ai`.
2. Upload/extract the contents of this project into the repository and push them to the `main` branch.
3. Open the repository's **Settings → Secrets and variables → Actions → New repository secret** and add:
   - `SUPABASE_URL` = your Supabase Project URL
   - `SUPABASE_ANON_KEY` = your Supabase anon/publishable client key
4. Open **Actions → Build NSTU StudyMate AI APK → Run workflow** (or wait for the `main` branch push build to finish).
5. Open the successful workflow run, scroll to **Artifacts**, and download `NSTU-StudyMate-AI-APK`.
6. Extract the downloaded artifact ZIP. It contains `app-release.apk`. Transfer it to your Android phone and install it. Android may ask you to allow installation from that source.

If the Supabase secrets are omitted, a build may still succeed, but the app will show a setup-required screen and AI upload features will not work.

## 3. Build locally (optional)

Install Flutter stable, Android Studio, and the Android SDK. Then run in the project folder:

```bash
flutter create --platforms=android --org=bd.ac.nstu .
flutter pub get
flutter build apk --release \
  --dart-define=SUPABASE_URL="YOUR_SUPABASE_URL" \
  --dart-define=SUPABASE_ANON_KEY="YOUR_SUPABASE_ANON_KEY"
```

The APK is written to `build/app/outputs/flutter-apk/app-release.apk`.

## Limitations to know

- Scanned/image-only PDFs are not supported yet; the PDF must contain selectable text. OCR is a future enhancement.
- Research directions are suggestions from the uploaded material; live web research and external citations are not implemented yet.
- This is an MVP. Before public distribution, add rate limits/quotas, better upload limits and error handling, privacy terms, and production testing.
